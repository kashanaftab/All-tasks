#include<iostream>
using namespace std;
int main(){
	int x=4;
	cout<<"enter a number"<<x<<endl;
	do{
			cout<<x<<endl;
		x++;

	}
	while(x<8);
	
	
	
	return 0;
}