#include<iostream>
using namespace std;
int main(){
	int x=5;
	cout<<"enter a number"<<x<<endl;
	while(x<10){
		cout<<x<<endl;
		x++;
	}
	return 0;
}