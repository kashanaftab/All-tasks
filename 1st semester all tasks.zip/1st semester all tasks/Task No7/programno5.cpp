#include<iostream>
using namespace std;
int main(){
	int x=5;
	do{
		cout<<x<<endl;
		x--;
	}while(x>0);
	return 0;
}