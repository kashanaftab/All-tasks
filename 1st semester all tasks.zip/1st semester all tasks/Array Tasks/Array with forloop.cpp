#include<iostream>
using namespace std;
int main(){
	
	int roll[5]={1,3,5,7,9};
	for(int i=0;i<=4;i++){
		cout<<roll[i];
	}
	return 0;
}