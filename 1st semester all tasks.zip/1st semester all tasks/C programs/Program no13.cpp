#include<iostream>
using namespace std;
int main(){
	cout<<"\"hello \t world"<<endl;
		cout<<"hello\bworld"<<endl;
		cout<<"C:\\Desktop"<<endl;
//		printf("5+7=%d",5+7);
			printf("5.7+7=%e",5.7+7);
//			\o for octal view of answer and \x is for hexa view 

	return 0;
}