#include<iostream>
using namespace std;
int main(){
	int a=6;
	cout<<&a;
	return 0;
}