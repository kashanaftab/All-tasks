#include <iostream>
using namespace std;
int main() {
	int x = 10;
if (x > 20) { 
    cout << "x is greater than 20"; 
} else if (x == 10) { 
    cout << "x is equal to 10"; 
} else if (x < 0) { 
    cout << "x is less than 0"; 
} else { 
    cout << "x is between 0 and 20"; 
}
return 0;
}
