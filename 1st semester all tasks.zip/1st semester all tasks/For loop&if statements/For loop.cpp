#include<iostream>
using namespace std;
int main(){
	for(int a=0;a<=5;a++){
		cout<<a<<endl;
		if(a==5){
			cout<<"the number is equal to 5"<<endl;
		}
	}
}