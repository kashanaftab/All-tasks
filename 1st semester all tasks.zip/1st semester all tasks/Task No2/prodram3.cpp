#include<iostream>
using namespace std;
int main(){

int x=15;
int y=9;
int z=(x+y)/7;
cout<<z<<endl;
return 0;
}