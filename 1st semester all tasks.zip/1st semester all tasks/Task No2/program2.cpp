#include<iostream>
using namespace std;
int main(){

int x=5;
int y=5;
int z=3*x+y;

cout<<z<<endl;
return 0;
}