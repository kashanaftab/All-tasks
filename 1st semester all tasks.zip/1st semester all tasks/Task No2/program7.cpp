#include<iostream>
using namespace std;
int main(){

int a=33;
int b=12;

cout<<a/b<<endl;
cout<<a%b<<endl;
return 0;
}