#include<iostream>
using namespace std;
int main(){

double c=20;
double f;
 f=(9/5)*c+32.0;
cout<<f<<endl;
return 0;
}