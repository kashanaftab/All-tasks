#include<iostream>
using namespace std;
int main(){

int number=(1/3)*3;
cout<<"(1/3)*3 is equal to: "<<number<<endl;
return 0;
}