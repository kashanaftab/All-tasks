#include<iostream>
using namespace std;
int main(){

int x=5;
int y=3*x;
cout<<y<<endl;
return 0;
}