#include<iostream>
using namespace std;
int main(){

int x=15;
int y=9;
int z=7;
int mul=(3*x+y)/(z+2);
cout<<mul<<endl;
return 0;
}