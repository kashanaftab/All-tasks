#include<iostream>
using namespace std;
int main(){

char a,b,c;
a='b';
b='c';
c=a;
cout<<a<<b<<c<<endl;
return 0;
}