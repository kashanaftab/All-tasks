#include<iostream>
#include<string>
using namespace std;
int main(){
string month,day,year,date;
 month= "03 ,";
 day= "04 ,";
 year= "06 ,";
 date =month+day+year;
cout<<date<<endl;

return 0;
}