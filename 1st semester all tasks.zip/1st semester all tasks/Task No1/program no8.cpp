#include<iostream>
using namespace std;
int main(){
	int u,t,a,s;
	u=8;
	t=7;
	a=2;
	s=u*t+1/2*a;
	cout<<"s="<<s<<endl;
	return 0;
}