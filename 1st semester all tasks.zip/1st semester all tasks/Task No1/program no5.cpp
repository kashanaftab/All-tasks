#include<iostream>
using namespace std;
int main(){
	int h,w,area,circumference;
	h=5;
	w=8;
	area=h*w;
	circumference=area*w;
	cout<<"area="<<area<<endl;
	cout<<"circumference="<<circumference<<endl;
	return 0;
}