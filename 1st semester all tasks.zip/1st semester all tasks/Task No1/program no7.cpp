#include<iostream>
using namespace std;
int main(){
	short a,b,c,d,e,f;
	a=5;
	b=5;
	c=a+b;
	d=a/b;
	e=a*b;
	f=a%b;
	cout<<"c="<<c<<endl;
	cout<<"d="<<d<<endl;
	cout<<"e="<<e<<endl;
	cout<<"f="<<f<<endl;
}  