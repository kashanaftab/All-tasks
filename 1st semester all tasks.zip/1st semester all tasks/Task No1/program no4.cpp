#include<iostream>
using namespace std;
int main(){
	int a,b,Mul;
	a=6;
	b=7;
	Mul=a*b;
	cout<<"Sum="<<a+b<<endl;
	cout<<"Mul="<<Mul<<endl;
	return 0;
}