#include<iostream>
using namespace std;
int main(){
	int u,a,t,v;
	u=10;
	a=6;
	t=9;
	v=u+a*t;
	cout<<"v="<<v<<endl;
	return 0;
}