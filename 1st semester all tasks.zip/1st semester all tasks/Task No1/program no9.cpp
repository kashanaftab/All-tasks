#include<iostream>
#include<cmath>
using namespace std;
int main(){
	int a,b,c,t;
	a=23;
	b=54;
	c=9;
	t=2*a+sqrt(b)+9*c;
	cout<<"t="<<t<<endl;
	return 0;
}