#include<iostream>
using namespace std;
int main(){
		int x,y,z;
	x=6;
	y=7;
	z=x+y;
	cout<<"z="<<z<<endl;
	return 0;
}