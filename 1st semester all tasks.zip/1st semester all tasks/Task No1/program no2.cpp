#include<iostream>
using namespace std;
int main(){
	int h,w,d,volume;
	h=6;
	w=7;
	d=8;
	volume=h*w*d;
	cout<<"volume="<<volume<<endl;
	return 0;
}