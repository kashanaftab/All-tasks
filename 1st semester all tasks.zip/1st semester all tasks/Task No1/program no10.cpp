#include<iostream>
#include<cmath>
using namespace std;
int main(){
	int b,p,h;
	b=23;
	p=54;
	h=sqrt(b*b)+p*p;
	cout<<"h="<<h<<endl;
	return 0;
}