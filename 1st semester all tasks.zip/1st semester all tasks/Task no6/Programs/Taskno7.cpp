
#include <iostream>
using namespace std;
int main() {
   
    if (0) {
        cout << "0 is true" << endl;
    } else {
    	cout << "0 is false" << endl;
    }

    
    if (1) {
        cout << "1 is true" << endl;
    } else {
        cout << "1 is false" << endl;
    }

    
    if (-1) {
        cout << "-1 is true" << endl;
    } else {
        cout << "-1 is false" << endl;
    }

    return 0;
}