#include<iostream>
#include<fstream>
using namespace std;
int main(){
	ofstream file("test.text");
	file<<"students name (abdullah sahil zeeshan)"<<endl;
	return 0;	
}